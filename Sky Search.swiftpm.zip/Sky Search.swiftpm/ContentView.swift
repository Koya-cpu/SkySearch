import SwiftUI

struct ContentView: View {
    @AppStorage("language") private var language: String = "English"
    @AppStorage("SettingOK") private var SettingOK: Bool = false
    
    var body: some View {
        
        if SettingOK == false {
            Text(language == "English" ? "Select Your Language" : language == "Spanish" ? "Selecciona el idioma" : language == "France" ? "Veuillez sélectionner \n une langue" : language == "Korean" ? "언어를 설정해 주세요" : language == "Japanese" ? "言語設定" : "请设置语言")
                .font(.title)
                .multilineTextAlignment(.center)
            
            Picker("language", selection: $language){
                Text("Español")
                    .tag("Spanish")
                Text("Français")
                    .tag("France")
                Text("English")
                    .tag("English")
                Text("한국어")
                    .tag("Korean")
                Text("日本語")
                    .tag("Japanese")
                Text("简体中文")
                    .tag("Chinese")
            }
            .pickerStyle(.wheel)
            
            
            Button(language == "English" ? "Next" : language == "Spanish" ? "Siguiente" : language == "France" ? "Suivant" : language == "Korean" ? "다음" : language == "Japanese" ? "次へ" : "下一页"){
                SettingOK = true
            }
            .frame(width: 100, height: 30)
            .foregroundColor(.white)
            .background(.blue)
            .cornerRadius(10)
            
            .padding(20)
            
        } else {
            SetView()
        }
        
    }
}

struct SetView: View {
    @AppStorage("language") private var language: String = "English"
    @AppStorage("SettingOK") private var SettingOK: Bool = false
    @AppStorage("love") private var love: String = ""
    @AppStorage("Setting2OK") private var Setting2OK: Bool = false
    
    var body: some View {
        
        if Setting2OK == false {
            
            VStack{
                
                Text(language == "English" ? "What are you interested in ?" : language == "Spanish" ? "¿Qué te interesa?" : language == "France" ? "Qu'est-ce qui t'intéresse ?" : language == "Korean" ? "무엇에 관심이 있으신가요?" : language == "Japanese" ? "何に興味がありますか？" : "你对什么感兴趣？")
                    .font(.title)
                
                HStack{
                    Button{
                        love = "Food"
                    } label: {
                        
                        Text(language == "English" ? "Food" : language == "Spanish" ? "Comida" : language == "France" ? "Nourriture" : language == "Korean" ? "음식" : language == "Japanese" ? "食べ物" : "食物")
                            .frame(width: 150, height: 150)
                            .background(Color(.systemGray5))
                            .cornerRadius(10)
                            .scaleEffect(love == "Food" ? 0.93 : 1.0)
                    }
                    .buttonStyle(.plain)
                    
                    Button{
                        love = "View"
                    } label: {
                        Text(language == "English" ? "Sightseeing" : language == "Spanish" ? "Turismo" : language == "France" ? "Tourisme" : language == "Korean" ? "관광" : language == "Japanese" ? "観光" : "旅游")
                            .frame(width: 150, height: 150)
                            .background(Color(.systemGray5))
                            .cornerRadius(10)
                            .scaleEffect(love == "View" ? 0.93 : 1.0)
                    }
                    .buttonStyle(.plain)
                }
                
                HStack{
                    Button{
                        love = "Nature"
                    } label: {
                        Text(language == "English" ? "Nature" : language == "Spanish" ? "Naturaleza" : language == "France" ? "Nature" : language == "Korean" ? "자연" : language == "Japanese" ? "自然" : "自然")
                            .frame(width: 150, height: 150)
                            .background(Color(.systemGray5))
                            .cornerRadius(10)
                            .scaleEffect(love == "Nature" ? 0.93 : 1.0)
                    }
                    .buttonStyle(.plain)
                    
                    Button{
                        love = "Culture"
                    } label: {
                        Text(language == "English" ? "Culture" : language == "Spanish" ? "Cultura" : language == "France" ? "Culture" : language == "Korean" ? "문화" : language == "Japanese" ? "文化" : "文化")
                            .frame(width: 150, height: 150)
                            .background(Color(.systemGray5))
                            .cornerRadius(10)
                            .scaleEffect(love == "Culture" ? 0.93 : 1.0)
                    }
                    .buttonStyle(.plain)
                }
                
                if love.isEmpty {
                    
                } else {
                    Button(language == "English" ? "Next" : language == "Spanish" ? "Siguiente" : language == "France" ? "Suivant" : language == "Korean" ? "다음" : language == "Japanese" ? "次へ" : "下一页"){
                        Setting2OK = true
                    }
                    .frame(width: 100, height: 30)
                    .foregroundColor(.white)
                    .background(.blue)
                    .cornerRadius(10)
                    .padding(30)
                }
                
                Button("初期化"){
                    language = "English"
                    SettingOK = false
                }
            }
        } else {
            HomeView()
        }
        
    }
}

struct HomeView: View {
    var body: some View {
        TabView{
            HomePage()
                .tabItem {
                    Label("ホーム", systemImage: "house")
                }
            SettingPage()
                .tabItem {
                    Label("設定", systemImage: "gear")
                }
        }
        
    }
}

struct HomePage: View {
    @AppStorage("language") private var language: String = "English"
    @AppStorage("SettingOK") private var SettingOK: Bool = false
    @AppStorage("love") private var love: String = ""
    @AppStorage("Setting2OK") private var Setting2OK: Bool = false
    var body: some View {
        Button("初期化"){
            language = "English"
            SettingOK = false
            love = ""
            Setting2OK = false
        }
    }
}

struct SettingPage: View {
    var body: some View {
        VStack{
            Text("yaa")
        }
    }
}

#Preview {
    ContentView()
}
